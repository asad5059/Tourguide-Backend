from django.contrib import admin
from .models import PlaceInfoModel
# Register your models here.
admin.site.register(PlaceInfoModel)